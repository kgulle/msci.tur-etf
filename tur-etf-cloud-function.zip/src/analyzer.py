"""
analyzer.py — Iki portfoy snapshot'i arasindaki degisiklikleri analiz eder
"""

import logging
import json
from datetime import date
from pathlib import Path
from typing import Optional
import pandas as pd

logger = logging.getLogger(__name__)


class PortfolioChange:
    """Iki tarih arasindaki portfoy degisiklik analizi."""

    def __init__(self, prev_date: date, curr_date: date, prev_df: pd.DataFrame, curr_df: pd.DataFrame):
        self.prev_date = prev_date
        self.curr_date = curr_date
        self.prev_df = prev_df.copy()
        self.curr_df = curr_df.copy()

        # Tum analizleri calistir
        self._run_analysis()

    @property
    def has_changes(self) -> bool:
        """Portfoyde gercek bir agirlik veya hisse degisimi olup olmadigini dondurur."""
        return bool(len(self.increased) > 0 or len(self.decreased) > 0 or self.new_entries or self.exits)

    def _run_analysis(self):
        """Tum analiz hesaplamalarini yapar."""
        prev_tickers = set(self.prev_df["ticker"])
        curr_tickers = set(self.curr_df["ticker"])

        # Yeni girenler (onceki listede yok, simdi var)
        self.new_entries = sorted(curr_tickers - prev_tickers)

        # Cikanlar (onceki listede vardi, simdi yok)
        self.exits = sorted(prev_tickers - curr_tickers)

        # Ortak hisseler icin agirlik degisimi
        common = prev_tickers & curr_tickers

        prev_weights = self.prev_df.set_index("ticker")["weight_pct"]
        curr_weights = self.curr_df.set_index("ticker")["weight_pct"]

        changes = []
        for ticker in common:
            pw = float(prev_weights.get(ticker, 0))
            cw = float(curr_weights.get(ticker, 0))
            change_pp = round(cw - pw, 4)
            change_pct = round((change_pp / pw * 100) if pw > 0 else 0, 2)

            curr_row = self.curr_df[self.curr_df["ticker"] == ticker].iloc[0]

            changes.append({
                "ticker": ticker,
                "name": curr_row.get("name", ticker),
                "sector": curr_row.get("sector", ""),
                "prev_weight": pw,
                "curr_weight": cw,
                "change_pp": change_pp,
                "change_pct": change_pct,
                "curr_price": float(curr_row.get("price", 0)),
                "curr_market_value": float(curr_row.get("market_value", 0)),
                "curr_quantity": float(curr_row.get("quantity", 0)),
            })

        self.changes_df = pd.DataFrame(changes).sort_values("change_pp", ascending=False)

        # Artanlar (pozitif degisim)
        self.increased = self.changes_df[self.changes_df["change_pp"] > 0.001].copy()

        # Azalanlar (negatif degisim)
        self.decreased = self.changes_df[self.changes_df["change_pp"] < -0.001].copy()

        # Sabit kalanlar
        self.unchanged = self.changes_df[
            (self.changes_df["change_pp"] >= -0.001) &
            (self.changes_df["change_pp"] <= 0.001)
        ].copy()

        # Yeni girenlerin detaylari
        self.new_entries_detail = self.curr_df[
            self.curr_df["ticker"].isin(self.new_entries)
        ].copy()

        # Cikanlarin detaylari
        self.exits_detail = self.prev_df[
            self.prev_df["ticker"].isin(self.exits)
        ].copy()

        # Sektor bazli analiz
        self.sector_analysis = self._compute_sector_analysis()

        # Ozet istatistikler
        self.summary = {
            "prev_date": self.prev_date.strftime("%Y-%m-%d"),
            "curr_date": self.curr_date.strftime("%Y-%m-%d"),
            "prev_holdings_count": len(self.prev_df),
            "curr_holdings_count": len(self.curr_df),
            "new_entries_count": len(self.new_entries),
            "exits_count": len(self.exits),
            "increased_count": len(self.increased),
            "decreased_count": len(self.decreased),
            "unchanged_count": len(self.unchanged),
            "top_gainer": self.increased.iloc[0]["ticker"] if not self.increased.empty else None,
            "top_gainer_change": float(self.increased.iloc[0]["change_pp"]) if not self.increased.empty else 0,
            "top_loser": self.decreased.iloc[-1]["ticker"] if not self.decreased.empty else None,
            "top_loser_change": float(self.decreased.iloc[-1]["change_pp"]) if not self.decreased.empty else 0,
        }

    def _compute_sector_analysis(self) -> pd.DataFrame:
        """Sektor bazli agirlik degisimi hesaplar."""
        prev_sector = (
            self.prev_df.groupby("sector")["weight_pct"].sum().reset_index()
            .rename(columns={"weight_pct": "prev_weight"})
        )
        curr_sector = (
            self.curr_df.groupby("sector")["weight_pct"].sum().reset_index()
            .rename(columns={"weight_pct": "curr_weight"})
        )
        sector_df = pd.merge(prev_sector, curr_sector, on="sector", how="outer").fillna(0)
        sector_df["change_pp"] = (sector_df["curr_weight"] - sector_df["prev_weight"]).round(4)
        sector_df["change_pct"] = (
            sector_df.apply(
                lambda r: round((r["change_pp"] / r["prev_weight"] * 100) if r["prev_weight"] > 0 else 0, 2),
                axis=1
            )
        )
        return sector_df.sort_values("change_pp", ascending=False)

    def print_report(self):
        """Konsola analiz raporunu yazdirir."""
        print(f"\n{'='*70}")
        print(f"  TUR ETF PORTFOY DEGISIKLIK RAPORU")
        print(f"  Tarih: {self.prev_date} --> {self.curr_date}")
        print(f"{'='*70}\n")

        print(f"  Toplam Hisse: {self.summary['prev_holdings_count']} --> {self.summary['curr_holdings_count']}")
        if self.new_entries:
            print(f"  [YENi GIREN] ({len(self.new_entries)}): {', '.join(self.new_entries)}")
        if self.exits:
            print(f"  [CIKAN]      ({len(self.exits)}): {', '.join(self.exits)}")

        # En cok artan
        if not self.increased.empty:
            print(f"\n  AGIRLIK ARTAN POZISYONLAR (Ilk 10):")
            print(f"  {'Tiker':<12} {'Isim':<38} {'Onceki':>8} {'Yeni':>8} {'Degisim':>10}")
            print(f"  {'-'*80}")
            for _, row in self.increased.head(10).iterrows():
                print(
                    f"  {row['ticker']:<12} {str(row['name'])[:37]:<38} "
                    f"{row['prev_weight']:>7.2f}% {row['curr_weight']:>7.2f}% "
                    f"+{row['change_pp']:>8.4f}pp"
                )

        # En cok azalan
        if not self.decreased.empty:
            print(f"\n  AGIRLIK AZALAN POZISYONLAR (Ilk 10):")
            print(f"  {'Tiker':<12} {'Isim':<38} {'Onceki':>8} {'Yeni':>8} {'Degisim':>10}")
            print(f"  {'-'*80}")
            for _, row in self.decreased.tail(10).iterrows():
                print(
                    f"  {row['ticker']:<12} {str(row['name'])[:37]:<38} "
                    f"{row['prev_weight']:>7.2f}% {row['curr_weight']:>7.2f}% "
                    f"{row['change_pp']:>9.4f}pp"
                )

        # Sektor analizi
        print(f"\n  SEKTOR BAZLI DEGISIM:")
        print(f"  {'Sektor':<32} {'Onceki':>8} {'Yeni':>8} {'Degisim':>10}")
        print(f"  {'-'*65}")
        for _, row in self.sector_analysis.iterrows():
            change_str = f"{row['change_pp']:+.4f}pp"
            print(
                f"  {str(row['sector'])[:31]:<32} "
                f"{row['prev_weight']:>7.2f}% {row['curr_weight']:>7.2f}% "
                f"{change_str:>10}"
            )

        print(f"\n{'='*70}\n")

    def to_dict(self) -> dict:
        """Tum analiz sonuclarini dict'e donusturur."""
        return {
            "summary": self.summary,
            "increased": self.increased.to_dict(orient="records"),
            "decreased": self.decreased.to_dict(orient="records"),
            "unchanged": self.unchanged.to_dict(orient="records"),
            "new_entries": self.new_entries_detail.to_dict(orient="records"),
            "exits": self.exits_detail.to_dict(orient="records"),
            "sector_analysis": self.sector_analysis.to_dict(orient="records"),
        }

    def save_json(self, changes_dir: str = "data/changes"):
        """Analiz sonucunu JSON dosyasina kaydeder."""
        Path(changes_dir).mkdir(parents=True, exist_ok=True)
        filename = f"{self.curr_date.strftime('%Y%m%d')}_changes.json"
        path = Path(changes_dir) / filename
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2, default=str)
        logger.info(f"Degisim raporu kaydedildi: {path}")
        return path


def compare_snapshots(
    prev_df: pd.DataFrame,
    curr_df: pd.DataFrame,
    prev_date: date,
    curr_date: date,
) -> Optional[PortfolioChange]:
    """Iki snapshot'i karsilastirir ve PortfolioChange dondurur."""
    if prev_df is None or curr_df is None:
        logger.error("Karsilastirma icin her iki snapshot da gereklidir")
        return None
    if prev_df.empty or curr_df.empty:
        logger.warning("Bos snapshot'lar karsilastirilamaz")
        return None

    return PortfolioChange(prev_date, curr_date, prev_df, curr_df)


def build_historical_weight_matrix(snapshot_dir: str = "data/snapshots") -> pd.DataFrame:
    """
    Tum snapshot'lardan zaman serisi agirlik matrisi olusturur.
    Satirlar = tarihler, Sutunlar = tiker sembolleri
    """
    from fetcher import get_available_snapshots, load_snapshot

    dates = get_available_snapshots(snapshot_dir)
    if not dates:
        logger.warning("Hic snapshot bulunamadi")
        return pd.DataFrame()

    all_data = []
    for d in dates:
        path = Path(snapshot_dir) / f"{d.strftime('%Y%m%d')}.csv"
        df = load_snapshot(path)
        if df is not None and not df.empty:
            row = {"date": d.strftime("%Y-%m-%d")}
            for _, stock_row in df.iterrows():
                row[stock_row["ticker"]] = stock_row["weight_pct"]
            all_data.append(row)

    if not all_data:
        return pd.DataFrame()

    matrix = pd.DataFrame(all_data).set_index("date").fillna(0)
    matrix = matrix.sort_index()
    logger.info(f"Tarihsel agirlik matrisi olusturuldu: {matrix.shape[0]} gun x {matrix.shape[1]} hisse")
    return matrix
