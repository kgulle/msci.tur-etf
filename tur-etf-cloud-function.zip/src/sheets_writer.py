"""
sheets_writer.py — Google Sheets'e portföy analiz verisi yazar
"""

import logging
import time
from datetime import date, datetime
from typing import Optional
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials

logger = logging.getLogger(__name__)

# Google Sheets API'si için gerekli izinler
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

# Sekme isimleri
SHEET_NAMES = {
    "current":      "📊 Güncel Portföy",
    "history":      "📈 Değişim Geçmişi",
    "increased":    "🚀 Pozisyon Artışları",
    "decreased":    "📉 Pozisyon Düşüşleri",
    "new_entries":  "🆕 Yeni Girenler",
    "exits":        "🚪 Çıkanlar",
    "raw_data":     "📋 Ham Veri",
    "sector":       "🏭 Sektör Analizi",
    "weight_matrix":"📅 Ağırlık Matrisi",
}

# Sekme başlık renkleri (RGB)
SHEET_COLORS = {
    "current":     {"red": 0.13, "green": 0.33, "blue": 0.55},
    "history":     {"red": 0.20, "green": 0.40, "blue": 0.60},
    "increased":   {"red": 0.07, "green": 0.53, "blue": 0.30},
    "decreased":   {"red": 0.70, "green": 0.15, "blue": 0.15},
    "new_entries": {"red": 0.07, "green": 0.53, "blue": 0.35},
    "exits":       {"red": 0.65, "green": 0.25, "blue": 0.10},
    "raw_data":    {"red": 0.35, "green": 0.35, "blue": 0.35},
    "sector":      {"red": 0.40, "green": 0.20, "blue": 0.60},
    "weight_matrix":{"red": 0.80, "green": 0.40, "blue": 0.20},
}


class SheetsWriter:
    """Google Sheets yazıcı sınıfı."""

    def __init__(self, spreadsheet_id: str, service_account_file: str):
        self.spreadsheet_id = spreadsheet_id
        self.service_account_file = service_account_file
        self.gc: Optional[gspread.Client] = None
        self.spreadsheet: Optional[gspread.Spreadsheet] = None

    def connect(self):
        """Google Sheets API'ye bağlanır."""
        try:
            creds = Credentials.from_service_account_file(
                self.service_account_file, scopes=SCOPES
            )
            self.gc = gspread.authorize(creds)
            self.spreadsheet = self.gc.open_by_key(self.spreadsheet_id)
            logger.info(f"✅ Google Sheets bağlantısı başarılı: '{self.spreadsheet.title}'")
            return True
        except FileNotFoundError:
            logger.error(
                f"❌ Service account dosyası bulunamadı: {self.service_account_file}\n"
                f"   setup_google_sheets.py ile kurulumu tamamlayın."
            )
            return False
        except gspread.exceptions.APIError as e:
            logger.error(f"❌ Google Sheets API hatası: {e}")
            return False
        except Exception as e:
            logger.error(f"❌ Bağlantı hatası: {e}")
            return False

    def setup_sheets(self):
        """Gerekli sekmeleri oluşturur veya günceller."""
        if not self.spreadsheet:
            logger.error("Önce connect() çağırın")
            return

        existing = {ws.title: ws for ws in self.spreadsheet.worksheets()}

        for key, name in SHEET_NAMES.items():
            if name not in existing:
                logger.info(f"  📑 '{name}' sekmesi oluşturuluyor...")
                ws = self.spreadsheet.add_worksheet(title=name, rows=5000, cols=30)
                # Sekme rengi ayarla
                color = SHEET_COLORS.get(key, {"red": 0.5, "green": 0.5, "blue": 0.5})
                self.spreadsheet.batch_update({
                    "requests": [{
                        "updateSheetProperties": {
                            "properties": {
                                "sheetId": ws.id,
                                "tabColor": color,
                            },
                            "fields": "tabColor",
                        }
                    }]
                })
                time.sleep(0.5)
            else:
                logger.debug(f"  ✓ '{name}' sekmesi zaten mevcut")

        logger.info("✅ Tüm sekmeler hazır")

    def _get_sheet(self, key: str) -> Optional[gspread.Worksheet]:
        """Sekme adına göre worksheet döndürür."""
        name = SHEET_NAMES.get(key)
        if not name:
            return None
        try:
            return self.spreadsheet.worksheet(name)
        except gspread.WorksheetNotFound:
            logger.error(f"'{name}' sekmesi bulunamadı. setup_sheets() çalıştırın.")
            return None

    def _rate_limit(self, seconds: float = 2.0):
        """API rate limit için bekler."""
        time.sleep(seconds)

    def write_current_portfolio(self, df: pd.DataFrame, analysis=None):
        """
        📊 Güncel Portföy sekmesini günceller.
        Her çalıştırmada tamamen yeniden yazılır.
        """
        ws = self._get_sheet("current")
        if ws is None:
            return

        headers = [
            "Sıra", "Tiker", "Şirket Adı", "Sektör",
            "Ağırlık (%)", "Piyasa Değeri (USD)",
            "Adet", "Fiyat (USD)",
            "Önceki Ağırlık (%)", "Değişim (pp)", "Durum",
            "Tarih"
        ]

        rows = [headers]
        for i, row in enumerate(df.itertuples(), 1):
            # Önceki veriden değişim bilgisi
            change_pp = ""
            status = ""
            prev_weight = ""

            if analysis:
                ticker = row.ticker
                if ticker in [e["ticker"] for e in analysis.get("new_entries", []) if isinstance(e, dict)]:
                    status = "🆕 Yeni"
                else:
                    # changes_df'ten bul
                    changes = {c["ticker"]: c for c in (
                        analysis.get("increased", []) +
                        analysis.get("decreased", []) +
                        analysis.get("unchanged", [])
                    ) if isinstance(c, dict)}
                    if ticker in changes:
                        c = changes[ticker]
                        prev_weight = c.get("prev_weight", "")
                        cp = c.get("change_pp", 0)
                        change_pp = f"+{cp:.4f}" if cp > 0 else f"{cp:.4f}"
                        if cp > 0.01:
                            status = "📈 Artan"
                        elif cp < -0.01:
                            status = "📉 Azalan"
                        else:
                            status = "➡️ Sabit"

            rows.append([
                i,
                getattr(row, "ticker", ""),
                getattr(row, "name", ""),
                getattr(row, "sector", ""),
                getattr(row, "weight_pct", ""),
                getattr(row, "market_value", ""),
                getattr(row, "quantity", ""),
                getattr(row, "price", ""),
                prev_weight,
                change_pp,
                status,
                getattr(row, "as_of_date", ""),
            ])

        ws.clear()
        self._rate_limit()
        ws.update(rows, "A1")
        self._rate_limit()

        # Başlık satırı formatı
        ws.format("A1:L1", {
            "backgroundColor": {"red": 0.13, "green": 0.33, "blue": 0.55},
            "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
        })
        self._rate_limit()

        # Sütun genişlikleri
        self.spreadsheet.batch_update({
            "requests": [
                {
                    "updateDimensionProperties": {
                        "range": {
                            "sheetId": ws.id,
                            "dimension": "COLUMNS",
                            "startIndex": 0,
                            "endIndex": 12,
                        },
                        "properties": {"pixelSize": 150},
                        "fields": "pixelSize",
                    }
                }
            ]
        })
        logger.info(f"  ✅ '{SHEET_NAMES['current']}' güncellendi ({len(df)} hisse)")
        self._rate_limit()

    def append_change_history(self, analysis: dict):
        """📈 Değişim Geçmişi sekmesine yeni satır ekler."""
        ws = self._get_sheet("history")
        if ws is None:
            return

        # Başlık yoksa ekle
        existing = ws.get_all_values()
        if not existing or len(existing) == 0 or len(existing[0]) == 0 or existing[0][0] != "Tarih":
            headers = [
                "Tarih", "Önceki Tarih",
                "Toplam Hisse (Önceki)", "Toplam Hisse (Yeni)",
                "Yeni Giren", "Çıkan",
                "Ağırlığı Artan", "Ağırlığı Azalan",
                "En Çok Artan Tiker", "En Çok Artan (pp)",
                "En Çok Azalan Tiker", "En Çok Azalan (pp)",
            ]
            ws.insert_row(headers, 1)
            ws.format("A1:L1", {
                "backgroundColor": {"red": 0.20, "green": 0.40, "blue": 0.60},
                "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
            })
            self._rate_limit()

        s = analysis.get("summary", {})
        new_row = [
            s.get("curr_date", ""),
            s.get("prev_date", ""),
            s.get("prev_holdings_count", ""),
            s.get("curr_holdings_count", ""),
            s.get("new_entries_count", 0),
            s.get("exits_count", 0),
            s.get("increased_count", 0),
            s.get("decreased_count", 0),
            s.get("top_gainer", ""),
            s.get("top_gainer_change", 0),
            s.get("top_loser", ""),
            s.get("top_loser_change", 0),
        ]
        ws.append_row(new_row)
        self._rate_limit()
        logger.info(f"  ✅ '{SHEET_NAMES['history']}' güncellendi")

    def append_position_changes(self, analysis: dict, curr_date: date):
        """🚀📉 Pozisyon artış/düşüş sekmelerine yeni satırlar ekler."""
        date_str = curr_date.strftime("%Y-%m-%d")
        
        for key, data_key in [("increased", "increased"), ("decreased", "decreased")]:
            ws = self._get_sheet(key)
            if ws is None:
                continue

            records = analysis.get(data_key, [])
            if not records:
                continue

            existing = ws.get_all_values()
            if not existing or len(existing) == 0 or len(existing[0]) == 0 or existing[0][0] != "Tarih":
                headers = [
                    "Tarih", "Tiker", "Şirket Adı", "Sektör",
                    "Önceki Ağırlık (%)", "Yeni Ağırlık (%)",
                    "Değişim (pp)", "Değişim (%)",
                    "Fiyat (USD)", "Piyasa Değeri (USD)",
                ]
                ws.insert_row(headers, 1)
                color = {"red": 0.07, "green": 0.53, "blue": 0.30} if key == "increased" else {"red": 0.70, "green": 0.15, "blue": 0.15}
                ws.format("A1:J1", {
                    "backgroundColor": color,
                    "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
                })
                self._rate_limit()

            rows_to_add = []
            for rec in records:
                if not isinstance(rec, dict):
                    continue
                rows_to_add.append([
                    date_str,
                    rec.get("ticker", ""),
                    rec.get("name", ""),
                    rec.get("sector", ""),
                    rec.get("prev_weight", ""),
                    rec.get("curr_weight", ""),
                    rec.get("change_pp", ""),
                    rec.get("change_pct", ""),
                    rec.get("curr_price", ""),
                    rec.get("curr_market_value", ""),
                ])

            if rows_to_add:
                ws.append_rows(rows_to_add)
                self._rate_limit()
                logger.info(f"  ✅ '{SHEET_NAMES[key]}': {len(rows_to_add)} satır eklendi")

    def append_new_entries_exits(self, analysis: dict, curr_date: date, prev_date: date):
        """🆕🚪 Yeni girenler ve çıkanlar sekmelerini günceller."""
        date_str = curr_date.strftime("%Y-%m-%d")
        
        for key, data_key in [("new_entries", "new_entries"), ("exits", "exits")]:
            ws = self._get_sheet(key)
            if ws is None:
                continue

            records = analysis.get(data_key, [])
            if not records:
                continue

            existing = ws.get_all_values()
            if not existing or len(existing) == 0 or len(existing[0]) == 0 or existing[0][0] != "Tarih":
                headers = [
                    "Tarih", "Önceki Tarih", "Tiker", "Şirket Adı", "Sektör",
                    "Ağırlık (%)", "Piyasa Değeri (USD)", "Adet", "Fiyat (USD)",
                ]
                ws.insert_row(headers, 1)
                color = {"red": 0.07, "green": 0.53, "blue": 0.35} if key == "new_entries" else {"red": 0.65, "green": 0.25, "blue": 0.10}
                ws.format("A1:I1", {
                    "backgroundColor": color,
                    "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
                })
                self._rate_limit()

            rows_to_add = []
            for rec in records:
                if not isinstance(rec, dict):
                    continue
                rows_to_add.append([
                    date_str,
                    prev_date.strftime("%Y-%m-%d"),
                    rec.get("ticker", ""),
                    rec.get("name", ""),
                    rec.get("sector", ""),
                    rec.get("weight_pct", ""),
                    rec.get("market_value", ""),
                    rec.get("quantity", ""),
                    rec.get("price", ""),
                ])

            if rows_to_add:
                ws.append_rows(rows_to_add)
                self._rate_limit()
                logger.info(f"  ✅ '{SHEET_NAMES[key]}': {len(rows_to_add)} satır eklendi")

    def append_sector_analysis(self, analysis: dict, curr_date: date):
        """🏭 Sektör analizi sekmesine veri ekler."""
        ws = self._get_sheet("sector")
        if ws is None:
            return

        records = analysis.get("sector_analysis", [])
        if not records:
            return

        existing = ws.get_all_values()
        if not existing or len(existing) == 0 or len(existing[0]) == 0 or existing[0][0] != "Tarih":
            headers = [
                "Tarih", "Sektör",
                "Önceki Ağırlık (%)", "Yeni Ağırlık (%)",
                "Değişim (pp)", "Değişim (%)",
            ]
            ws.insert_row(headers, 1)
            ws.format("A1:F1", {
                "backgroundColor": {"red": 0.40, "green": 0.20, "blue": 0.60},
                "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
            })
            self._rate_limit()

        date_str = curr_date.strftime("%Y-%m-%d")
        rows_to_add = []
        for rec in records:
            if not isinstance(rec, dict):
                continue
            rows_to_add.append([
                date_str,
                rec.get("sector", ""),
                rec.get("prev_weight", ""),
                rec.get("curr_weight", ""),
                rec.get("change_pp", ""),
                rec.get("change_pct", ""),
            ])

        if rows_to_add:
            ws.append_rows(rows_to_add)
            self._rate_limit()
            logger.info(f"  ✅ '{SHEET_NAMES['sector']}': {len(rows_to_add)} sektör güncellendi")

    def append_raw_data(self, df: pd.DataFrame):
        """📋 Ham Veri sekmesine tüm holdings satırlarını ekler."""
        ws = self._get_sheet("raw_data")
        if ws is None:
            return

        existing = ws.get_all_values()
        if not existing or len(existing) == 0 or len(existing[0]) == 0 or existing[0][0] != "as_of_date":
            # Başlıkları yaz
            headers = list(df.columns)
            ws.insert_row(headers, 1)
            ws.format("A1:P1", {
                "backgroundColor": {"red": 0.35, "green": 0.35, "blue": 0.35},
                "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}},
            })
            self._rate_limit()

        # Veri satırlarını ekle
        rows = df.values.tolist()
        # Sayısal None/NaN'ları boş string'e çevir
        clean_rows = []
        for row in rows:
            clean_rows.append([
                "" if (isinstance(v, float) and str(v) == "nan") else v
                for v in row
            ])

        if clean_rows:
            ws.append_rows(clean_rows)
            self._rate_limit()
            logger.info(f"  ✅ '{SHEET_NAMES['raw_data']}': {len(clean_rows)} satır eklendi")

    def write_all(self, curr_df: pd.DataFrame, analysis: dict, curr_date: date, prev_date: date):
        """Tüm sekmelere yazan ana metot."""
        logger.info(f"\n📝 Google Sheets yazılıyor ({curr_date})...")

        # 1. Güncel portföy (her zaman yeniden yaz)
        self.write_current_portfolio(curr_df, analysis)

        # 2. Değişim geçmişi (satır ekle)
        self.append_change_history(analysis)

        # 3. Pozisyon değişimleri
        self.append_position_changes(analysis, curr_date)

        # 4. Yeni girenler / çıkanlar
        self.append_new_entries_exits(analysis, curr_date, prev_date)

        # 5. Sektör analizi
        self.append_sector_analysis(analysis, curr_date)

        # 6. Ham veri
        self.append_raw_data(curr_df)
        
        # 7. Tarihsel Ağırlık Matrisi
        self.write_weight_matrix()

        logger.info("✅ Tüm Google Sheets güncellemeleri tamamlandı!\n")

    def write_weight_matrix(self, snapshot_dir: str = "data/snapshots"):
        """📅 Ağırlık Matrisi sekmesini günceller. Tüm tarihleri kapsayan bir pivot tablo oluşturur."""
        ws = self._get_sheet("weight_matrix")
        if ws is None:
            return

        from pathlib import Path
        import math
        
        path = Path(snapshot_dir)
        if not path.exists():
            return
            
        all_dfs = []
        for f in sorted(path.glob("*.csv")):
            try:
                date_str = f.stem
                try:
                    d_obj = datetime.strptime(date_str, "%Y%m%d").date()
                except ValueError:
                    continue
                    
                df = pd.read_csv(f)
                df.columns = [c.lower().strip() for c in df.columns]
                
                if "weight (%)" in df.columns:
                    df["weight_pct"] = pd.to_numeric(df["weight (%)"], errors="coerce") / 100.0
                    
                if "weight_pct" not in df.columns:
                    continue
                    
                df["weight_pct"] = df["weight_pct"].fillna(0.0)
                
                temp = df[["ticker", "name", "weight_pct"]].copy()
                temp["date"] = str(d_obj)
                
                # Temizle
                temp = temp.drop_duplicates(subset=["ticker"]).dropna(subset=["ticker"])
                all_dfs.append(temp)
            except Exception as e:
                logger.error(f"Matrix okuma hatasi {f.name}: {e}")
                
        if not all_dfs:
            return
            
        master_df = pd.concat(all_dfs, ignore_index=True)
        
        # Pivot
        pivot_df = master_df.pivot(index=["ticker", "name"], columns="date", values="weight_pct").fillna(0.0)
        
        # Sütunları tarihe göre sırala
        pivot_df = pivot_df[sorted(pivot_df.columns)]
        
        pivot_df = pivot_df.reset_index()
        
        headers = list(pivot_df.columns)
        raw_rows = pivot_df.values.tolist()
        
        # Clean NaNs
        rows = []
        for row in raw_rows:
            clean_row = [0.0 if (isinstance(x, float) and math.isnan(x)) else x for x in row]
            rows.append(clean_row)
        
        ws.clear()
        ws.update(values=[headers] + rows, range_name="A1")
        
        num_cols = len(headers)
        
        def col_name(n):
            s = ""
            while n > 0:
                n, remainder = divmod(n - 1, 26)
                s = chr(65 + remainder) + s
            return s
            
        end_col = col_name(num_cols)
        
        try:
            ws.format(f"C2:{end_col}", {
                "numberFormat": {
                    "type": "PERCENT",
                    "pattern": "0.00%"
                }
            })
            ws.format(f"A1:{end_col}1", {
                "backgroundColor": {"red": 0.8, "green": 0.4, "blue": 0.2},
                "textFormat": {"bold": True, "foregroundColor": {"red": 1, "green": 1, "blue": 1}}
            })
        except Exception as e:
            logger.warning(f"Formatlanamadi: {e}")
            
        self._rate_limit()
        logger.info(f"  ✅ '{SHEET_NAMES['weight_matrix']}' güncellendi")
